// config/cloudinary.js
import { v2 as cloudinary } from 'cloudinary';
import fs from 'fs';

const uploadOnCloudinary = async (filepath) => {
  cloudinary.config({ 
    cloud_name: process.env.CLOUDINARY_CLOUD_NAME, 
    api_key: process.env.CLOUDINARY_API_KEY, 
    api_secret: process.env.CLOUDINARY_API_SECRET
  });

  if (!filepath) {
    return null;
  }

  try {
    const uploadResult = await cloudinary.uploader.upload(filepath);
    // try unlink only if file exists
    try {
      if (fs.existsSync(filepath)) fs.unlinkSync(filepath);
    } catch (fsErr) {
      console.error("Failed to remove temp file:", fsErr);
    }
    return uploadResult.secure_url;
  } catch (error) {
    // if upload fails, attempt to unlink and then rethrow so caller can handle/log it
    try {
      if (fs.existsSync(filepath)) fs.unlinkSync(filepath);
    } catch (fsErr) {
      console.error("Failed to remove temp file after upload error:", fsErr);
    }
    console.error("cloudinary upload error:", error);
    throw error; // important: rethrow so addListing catch receives the real error
  }
};

export default uploadOnCloudinary;
