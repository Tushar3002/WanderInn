import mongoose from "mongoose";

const listingSchema=new mongoose.Schema({
    
})